document
  .getElementById("loginForm")
  ?.addEventListener("submit", function (event) {
    event.preventDefault();
    const email = document.getElementById("email").value;
    const password = document.getElementById("password").value;

    if (email && password) {
      window.location.href = "home.html";
    } else {
      alert("Por favor, completa todos los campos.");
    }
  });

function reservar() {
  window.location.href = "Info_reserva.html";
}

function reservarAula() {
  window.location.href = "Info_Aula.html";
}

function reservarAuditorio() {
  window.location.href = "info_Auditorio.html";
}
