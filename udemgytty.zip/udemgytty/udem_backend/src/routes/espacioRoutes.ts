import { Router } from "express";
import { body, param } from "express-validator";
import { EspacioController } from "../controllers/EspacioController";
import { handleInputErrors } from "../middleware/validation";
import { ReservaController } from "../controllers/ReservaController";

const router = Router();

// Rutas para gestionar espacios
router.post('/',
    body('nombre').notEmpty().withMessage('El nombre del espacio es obligatorio'),
    body('ubicacion').notEmpty().withMessage('La ubicación del espacio es obligatoria'),
    body('capacidad').isInt({ min: 1 }).withMessage('La capacidad debe ser un número entero mayor a 0'),
    body('disponibilidad').isBoolean().withMessage('La disponibilidad debe ser un valor booleano (true o false)'),
    handleInputErrors,
    EspacioController.createEspacios
);

router.get('/', EspacioController.getAllEspacios);

router.get('/:id',
    param('id').isMongoId().withMessage('ID no válido'),
    handleInputErrors,
    EspacioController.getEspacioById
);

router.put('/:id',
    param('id').isMongoId().withMessage('ID no válido'),
    body('nombre').notEmpty().withMessage('El nombre del espacio es obligatorio'),
    body('ubicacion').notEmpty().withMessage('La ubicación del espacio es obligatoria'),
    body('capacidad').isInt({ min: 1 }).withMessage('La capacidad debe ser un número entero mayor a 0'),
    body('disponibilidad').isBoolean().withMessage('La disponibilidad debe ser un valor booleano (true o false)'),
    handleInputErrors,
    EspacioController.updateEspacio
);

router.delete('/:id',
    param('id').isMongoId().withMessage('ID no válido'),
    handleInputErrors,
    EspacioController.deleteEspacio
);

// Rutas para reservas
router.post('/:espacioId/reservas', 
    ReservaController.createReserva
);

router.get('/:espacioId/reservas', 
    ReservaController.getReservasByEspacio
);

export default router;
