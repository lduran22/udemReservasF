import { Router } from "express";
import { body } from "express-validator";
import { handleInputErrors } from "../middleware/validation";
import { UsuarioController } from "../controllers/UsuarioController";

const router = Router();

// Ruta para crear un nuevo usuario
router.post(
    '/',
    body('email').isEmail().withMessage('El correo electrónico es obligatorio y debe ser válido'),
    body('password').notEmpty().withMessage('La contraseña es obligatoria'),
    handleInputErrors,
    UsuarioController.createUsuario
);

export default router;
