import mongoose, { Schema, Document } from "mongoose";

export interface IEspacio extends Document {
    nombre: string;
    ubicacion: string;
    capacidad: number;
    equipamiento: string[];
    disponibilidad: boolean;
    limiteReservasPorBloque: number; 
    reservas: mongoose.Types.ObjectId[]; 
}

const EspacioSchema: Schema = new Schema({
    nombre: {
        type: String,
        required: true,
        trim: true,
    },
    ubicacion: {
        type: String,
        required: true,
        trim: true,
    },
    capacidad: {
        type: Number,
        required: true,
    },
    equipamiento: {
        type: [String],
        default: [],
    },
    disponibilidad: {
        type: Boolean,
        default: true,
    },
    limiteReservasPorBloque: {
        type: Number,
        default: 1, 
    },
    reservas: [{
        type: mongoose.Types.ObjectId,
        ref: 'Reserva', 
    }],
});

const Espacio = mongoose.model<IEspacio>("Espacio", EspacioSchema);
export default Espacio;
