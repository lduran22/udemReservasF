import mongoose, { Schema, Document, Types } from "mongoose";

const reservaStatus = {
    CREATED: 'created',
    CONFIRMED: 'confirmed',
    CANCELLED: 'cancelled',
    MODIFIED: 'modified'
} as const;

export type ReservaStatus = typeof reservaStatus[keyof typeof reservaStatus];

export interface IReserva extends Document {
    espacio: Types.ObjectId; 
    usuario: Types.ObjectId; 
    fecha: Date; 
    horaInicio: number; 
    estado: ReservaStatus;
}

const ReservaSchema: Schema = new Schema({
    espacio: {
        type: Types.ObjectId,
        ref: 'Espacio',
        required: true
    },
    usuario: {
        type: Types.ObjectId,
        ref: 'Usuario',
        required: true
    },
    fecha: {
        type: Date,
        required: true
    },
    horaInicio: {
        type: Number,
        required: true,
        enum: [6, 8, 10, 12, 14, 16, 18] 
    },
    estado: {
        type: String,
        enum: Object.values(reservaStatus),
        default: reservaStatus.CREATED 
    }
}, { timestamps: true });

// Crea el modelo de Reserva
const Reserva = mongoose.model<IReserva>('Reserva', ReservaSchema);
export default Reserva;
