import mongoose, { Schema, Document } from 'mongoose';

export interface IUsuario extends Document {
    nombre: string;
    email: string;
    password: string;
}

const UsuarioSchema: Schema = new Schema({
    nombre: {
        type: String,
        required: [true, 'El nombre es obligatorio'],  // Asegura que el campo 'nombre' sea obligatorio
        trim: true,
    },
    email: {
        type: String,
        required: [true, 'El correo electrónico es obligatorio'],  // Asegura que el campo 'email' sea obligatorio
        unique: true,  // Asegura que el correo electrónico sea único
        match: [/.+@.+\..+/, 'Por favor ingrese un correo electrónico válido'],  // Valida el formato del correo
    },
    password: {
        type: String,
        required: [true, 'La contraseña es obligatoria'],  // Asegura que el campo 'password' sea obligatorio
        minlength: [6, 'La contraseña debe tener al menos 6 caracteres'],  // Valida que la contraseña tenga al menos 6 caracteres
    },
}, { timestamps: true });

const Usuario = mongoose.model<IUsuario>('Usuario', UsuarioSchema);
export default Usuario;
