import express from 'express';
import dotenv from 'dotenv';
import { connectDB } from './config/db';
import espacioRoutes from './routes/espacioRoutes';
import usuarioRoutes from './routes/usuarioRoutes'; // Asegúrate de importar las rutas de usuario

dotenv.config();

connectDB();

const app = express();

app.use(express.json());

// Routes
app.use('/api/espacios', espacioRoutes);
app.use('/api/usuarios', usuarioRoutes); // Asegúrate de usar el prefijo correcto

export default app;
