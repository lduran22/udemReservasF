import type { Request, Response } from "express";
import Usuario from "../models/Usuario";

export class UsuarioController {
    static createUsuario = async (req: Request, res: Response): Promise<void> => {
        const { nombre, email, password } = req.body;

        try {
            // Verificar si el usuario ya existe por correo electrónico
            const usuarioExistente = await Usuario.findOne({ email });
            if (usuarioExistente) {
                res.status(400).json({ error: "El correo electrónico ya está registrado" });
                return;
            }

            // Crear un nuevo usuario
            const nuevoUsuario = new Usuario({ nombre, email, password });
            await nuevoUsuario.save();

            res.status(201).json({ message: "Usuario creado correctamente", usuario: nuevoUsuario });
        } catch (error) {
            console.error(error);
            res.status(500).json({ error: "Hubo un error al crear el usuario." });
        }
    };

    // Puedes agregar más métodos aquí para manejar otras operaciones relacionadas con el usuario
}
