import type { Request, Response } from "express"
import Espacio from "../models/Espacio"

export class EspacioController {

    static createEspacios = async (req: Request, res: Response) => {

        const espacio = new Espacio(req.body)

        try {
            await espacio.save()
            res.send('Espacio Creado Correctamente')
        } catch (error) {
            console.log(error)
        }
    }

    static getAllEspacios = async (req: Request, res: Response) => {

        try {
            const espacios = await Espacio.find({})
            res.json(espacios)
        } catch (error) {
            console.log(error)
        }

    }

    static getEspacioById = async (req: Request, res: Response): Promise<void> => {  
        const { id } = req.params;
        try {
            const espacio = await Espacio.findById(id);
    
            if (!espacio) {
                const error = new Error('Espacio no encontrado');
                res.status(404).json({ error: error.message });
                return;
            }
    
            res.json(espacio);
        } catch (error: unknown) {
            console.error(error);
            const errorMessage = error instanceof Error ? error.message : 'Error al obtener el espacio';
            res.status(500).json({ error: errorMessage });
        }
    }

    static updateEspacio = async (req: Request, res: Response): Promise<void> => {  
        const { id } = req.params;
        try {
            const espacio = await Espacio.findByIdAndUpdate(id, req.body)

            if (!espacio) {
                const error = new Error('Espacio no encontrado');
                res.status(404).json({ error: error.message });
                return;
            }
            await espacio.save()
            res.send('Proyecto actualizado')
        } catch (error) {
            console.log(error)
            
        }

    }

    static deleteEspacio = async (req: Request, res: Response): Promise<void> => {  
        const { id } = req.params;
        try {
            const espacio = await Espacio.findById(id)
            
            if (!espacio) {
                const error = new Error('Espacio no encontrado');
                res.status(404).json({ error: error.message });
                return;
            }

            await espacio.deleteOne()
            res.send('Espacio eliminado')

        } catch (error) {
            console.log(error)
            
        }

    }
}