import type { Request, Response } from "express";
import Espacio from "../models/Espacio";
import Reserva from "../models/Reserva";

export class ReservaController {
  static createReserva = async (req: Request, res: Response) => {
    const { espacioId } = req.params;
    const { usuario, fecha, horaInicio } = req.body;

    const espacio = await Espacio.findById(espacioId);
    if (!espacio) {
      const error = new Error("Espacio no encontrado");
      res.status(404).json({ error: error.message });
      return;
    }

    try {
      const reservasEnBloque = await Reserva.countDocuments({
        espacio: espacioId,
        fecha: fecha,
        horaInicio: horaInicio,
      });

      if (reservasEnBloque >= espacio.limiteReservasPorBloque) {
        res
          .status(400)
          .json({
            error:
              "Se ha alcanzado el límite de reservas para este espacio en el horario especificado.",
          });
        return;
      }

      const reserva = new Reserva({
        usuario,
        espacio: espacioId,
        fecha,
        horaInicio,
      });

      await reserva.save();

      espacio.reservas.push(reserva.id);
      await espacio.save();

      res
        .status(201)
        .json({ message: "Reserva creada correctamente", reserva });
    } catch (error) {
      console.error(error);
      res.status(500).json({ error: "Hubo un error al crear la reserva." });
    }
  };

  // Nueva función para obtener todas las reservas de un espacio específico
  static getReservasByEspacio = async (req: Request, res: Response) => {
    const { espacioId } = req.params;

    try {
      const reservas = await Reserva.find({ espacio: espacioId })
        .populate("usuario", "nombre")
        .populate("espacio", "nombre ubicacion");
      res.json(reservas);
    } catch (error) {
      console.error(error);
      res.status(500).json({ error: "Hubo un error al obtener las reservas." });
    }
  };
}
